import { redirect } from 'next/navigation'

interface GroupPageProps {
  params: Promise<{ id: string }>
}

export default async function GroupPage({ params }: GroupPageProps) {
  await params
  redirect('/dashboard')
}
