import { Button } from '@/components/ui/button'
import { Trophy, Target, Clock, ArrowLeft } from 'lucide-react'
import Link from 'next/link'

export default function HowToPlayPage() {
  return (
    <div className="min-h-screen bg-background">
      <header className="bg-sky-navy border-b border-border">
        <div className="container mx-auto px-4 h-14 flex items-center gap-4">
          <Link href="/" className="flex items-center gap-2">
            <div className="bg-primary px-2 py-1 rounded">
              <span className="font-black text-sm text-primary-foreground tracking-tight">SCORES</span>
            </div>
            <span className="font-bold text-foreground hidden sm:inline">Round of 16</span>
          </Link>
        </div>
      </header>

      <div className="container max-w-2xl mx-auto px-4 py-6">
        <Link href="/">
          <Button variant="ghost" size="sm" className="mb-4">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
        </Link>

        <div className="text-center mb-8">
          <h1 className="text-2xl font-black uppercase tracking-wide mb-2">How to Play</h1>
          <p className="text-muted-foreground">A simple knockout prediction app.</p>
        </div>

        <div className="space-y-4">
          <div className="bg-card rounded-lg overflow-hidden">
            <div className="bg-primary px-4 py-2 flex items-center gap-2">
              <Target className="h-4 w-4 text-primary-foreground" />
              <span className="font-bold text-primary-foreground text-sm uppercase">Step 1: Log In</span>
            </div>
            <div className="p-4 text-sm text-muted-foreground">
              <p>Sign in to save your predictions.</p>
            </div>
          </div>

          <div className="bg-card rounded-lg overflow-hidden">
            <div className="bg-primary px-4 py-2 flex items-center gap-2">
              <Trophy className="h-4 w-4 text-primary-foreground" />
              <span className="font-bold text-primary-foreground text-sm uppercase">Step 2: Predict the Knockout</span>
            </div>
            <div className="p-4 text-sm text-muted-foreground">
              <p>Start at the Round of 16, then continue through the quarter-finals, semi-finals, and final.</p>
            </div>
          </div>

          <div className="bg-card rounded-lg overflow-hidden">
            <div className="bg-primary px-4 py-2 flex items-center gap-2">
              <Clock className="h-4 w-4 text-primary-foreground" />
              <span className="font-bold text-primary-foreground text-sm uppercase">Step 3: Save Before Kickoff</span>
            </div>
            <div className="p-4 text-sm text-muted-foreground">
              <p>Predictions lock when a match starts.</p>
            </div>
          </div>

          <div className="bg-card rounded-lg overflow-hidden border-2 border-primary/30">
            <div className="bg-primary px-4 py-3 flex items-center gap-2">
              <Trophy className="h-5 w-5 text-primary-foreground" />
              <span className="font-bold text-primary-foreground uppercase">Scoring</span>
            </div>
            <div className="p-4 text-sm text-muted-foreground">
              <p>Exact score: 5 points. Correct result: 2 points.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
