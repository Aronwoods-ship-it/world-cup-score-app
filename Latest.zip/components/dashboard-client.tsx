'use client'

import { DashboardHeader } from '@/components/dashboard-header'
import { KnockoutBracket } from '@/components/knockout-bracket'
import { Trophy } from 'lucide-react'

interface DashboardClientProps {
  displayName: string
}

export function DashboardClient({ displayName }: DashboardClientProps) {
  return (
    <div className="min-h-screen flex flex-col bg-[#f5f5f5]">
      <DashboardHeader displayName={displayName} />
      <main className="flex-1">
        <div className="container mx-auto px-4 py-6 space-y-6 max-w-4xl">
          <section className="space-y-4">
            <div className="flex items-center gap-2">
              <Trophy className="h-5 w-5 text-primary" />
              <div>
                <h1 className="text-xl font-bold uppercase tracking-wide">Round of 16 bracket</h1>
                <p className="text-sm text-muted-foreground">Clean knockout-only view.</p>
              </div>
            </div>
            <KnockoutBracket />
          </section>
        </div>
      </main>
      <footer className="py-4 px-4 text-center border-t border-[#e0e0e0] bg-white">
        <div className="flex items-center justify-center gap-2">
          <span className="text-[#999] text-xs">A</span>
          <span className="text-[#666] text-xs font-semibold tracking-wide">WOODS LABS INC.</span>
          <span className="text-[#999] text-xs">Product</span>
        </div>
      </footer>
    </div>
  )
}
