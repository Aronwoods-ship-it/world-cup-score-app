'use client'

import { Card } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { KNOCKOUT_ROUND_TREE } from '@/lib/knockout'
import { ChevronRight } from 'lucide-react'

export function KnockoutBracket() {
  return (
    <div className="space-y-6">
      <div className="bg-white border border-[#e0e0e0] rounded-lg p-4">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-lg font-bold text-[#001538]">Round of 16 onwards</h2>
            <p className="text-sm text-[#666]">
              Simple knockout view. Predict the winner from the Round of 16 through to the champion.
            </p>
          </div>
          <Badge variant="secondary" className="w-fit">
            Knockout only
          </Badge>
        </div>
      </div>

      <div className="space-y-6">
        {KNOCKOUT_ROUND_TREE.map((round, roundIndex) => (
          <section key={round.id} className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold uppercase tracking-wide text-[#001538]">{round.title}</h3>
              <span className="text-xs text-[#666]">{round.matchups.length} fixture{round.matchups.length === 1 ? '' : 's'}</span>
            </div>

            <div className="grid gap-3">
              {round.matchups.map((match) => (
                <Card key={match.id} className="overflow-hidden border-[#e0e0e0]">
                  <div className="bg-[#001538] px-4 py-2 flex items-center justify-between">
                    <p className="text-xs font-semibold uppercase tracking-wide text-white/80">
                      {round.title}
                    </p>
                    <span className="text-xs text-white/60">{match.id}</span>
                  </div>
                  <div className="p-4 grid grid-cols-[1fr_auto_1fr] items-center gap-3">
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[#001538] truncate">{match.homeLabel}</p>
                      <p className="text-xs text-[#666] mt-1">Home</p>
                    </div>
                    <div className="text-[#cc0000]">
                      <ChevronRight className="h-4 w-4 rotate-90 sm:rotate-0" />
                    </div>
                    <div className="min-w-0 text-right">
                      <p className="text-sm font-semibold text-[#001538] truncate">{match.awayLabel}</p>
                      <p className="text-xs text-[#666] mt-1">Away</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            {roundIndex < KNOCKOUT_ROUND_TREE.length - 1 && (
              <div className="flex justify-center">
                <div className="h-6 w-px bg-[#e0e0e0]" />
              </div>
            )}
          </section>
        ))}
      </div>

      <div className="bg-[#001538] text-white rounded-lg p-4">
        <p className="text-sm font-semibold uppercase tracking-wide">Path to the title</p>
        <p className="mt-1 text-sm text-white/80">Round of 16 → Quarter Finals → Semi Finals → Final → Champion</p>
      </div>
    </div>
  )
}
