'use client'

import { KnockoutBracket } from '@/components/knockout-bracket'
import type { MatchWithTeams, Prediction } from '@/lib/types'

interface MatchListProps {
  matches: MatchWithTeams[]
  predictions: Map<string, Prediction>
  groupId: string
  userId: string
  isGlobalView?: boolean
}

export function MatchList(_props: MatchListProps) {
  return <KnockoutBracket />
}
