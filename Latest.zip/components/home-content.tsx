'use client'

import Link from 'next/link'
import { Trophy, Target, Shield, ArrowRight } from 'lucide-react'

export function HomeContent() {
  return (
    <>
      <header className="sky-header">
        <div className="max-w-7xl mx-auto px-4 h-12 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="text-white font-light text-lg tracking-tight">da boyz</span>
            <span className="bg-[#cc0000] text-white font-bold text-sm px-1.5 py-0.5 rounded-sm">scores</span>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/auth/login" className="text-white/80 hover:text-white text-sm transition-colors">
              Log In
            </Link>
            <Link href="/auth/sign-up" className="bg-[#cc0000] hover:bg-[#aa0000] text-white text-sm font-semibold px-4 py-1.5 rounded transition-colors">
              Sign Up
            </Link>
          </div>
        </div>
      </header>

      <section className="bg-white py-16 px-6">
        <div className="max-w-3xl mx-auto text-center">
          <div className="inline-block mb-6">
            <span className="bg-[#001538] text-white text-xs font-bold px-3 py-1.5 rounded uppercase tracking-wider">
              World Cup Knockout Predictor
            </span>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold text-[#001538] mb-3">
            Round of 16 onwards
          </h1>

          <p className="text-[#666] text-lg max-w-xl mx-auto mb-8">
            A simple knockout app for predictions from the Round of 16, through the quarter-finals, semi-finals, and final.
          </p>

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/auth/sign-up" className="bg-[#cc0000] hover:bg-[#aa0000] text-white text-base font-bold px-8 py-3 rounded transition-colors inline-flex items-center justify-center gap-2">
              Sign Up
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link href="/auth/login" className="bg-white hover:bg-[#f5f5f5] text-[#001538] text-base font-semibold px-8 py-3 rounded border border-[#e0e0e0] transition-colors">
              Log In
            </Link>
          </div>

          <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-[#e0e0e0] bg-[#f8f8f8] px-4 py-2 text-sm font-medium text-[#001538]">
            <Shield className="h-4 w-4 text-[#cc0000]" />
            <span>Knockout only</span>
            <span>•</span>
            <Trophy className="h-4 w-4 text-[#cc0000]" />
            <span>Simple scoring</span>
            <span>•</span>
            <Target className="h-4 w-4 text-[#cc0000]" />
            <span>Fast predictions</span>
          </div>
        </div>
      </section>
    </>
  )
}
