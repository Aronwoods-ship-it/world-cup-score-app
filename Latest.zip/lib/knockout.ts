export type KnockoutStage = 'round_of_16' | 'quarter_final' | 'semi_final' | 'final'

export type KnockoutFixture = {
  id: string
  stage: KnockoutStage
  label: string
  homeLabel: string
  awayLabel: string
}

export const KNOCKOUT_STAGE_LABELS: Record<KnockoutStage, string> = {
  round_of_16: 'Round of 16',
  quarter_final: 'Quarter Finals',
  semi_final: 'Semi Finals',
  final: 'Final',
}

export const KNOCKOUT_FIXTURES: KnockoutFixture[] = [
  { id: 'r16-1', stage: 'round_of_16', label: 'Match 1', homeLabel: 'TBD', awayLabel: 'TBD' },
  { id: 'r16-2', stage: 'round_of_16', label: 'Match 2', homeLabel: 'TBD', awayLabel: 'TBD' },
  { id: 'r16-3', stage: 'round_of_16', label: 'Match 3', homeLabel: 'TBD', awayLabel: 'TBD' },
  { id: 'r16-4', stage: 'round_of_16', label: 'Match 4', homeLabel: 'TBD', awayLabel: 'TBD' },
  { id: 'r16-5', stage: 'round_of_16', label: 'Match 5', homeLabel: 'TBD', awayLabel: 'TBD' },
  { id: 'r16-6', stage: 'round_of_16', label: 'Match 6', homeLabel: 'TBD', awayLabel: 'TBD' },
  { id: 'r16-7', stage: 'round_of_16', label: 'Match 7', homeLabel: 'TBD', awayLabel: 'TBD' },
  { id: 'r16-8', stage: 'round_of_16', label: 'Match 8', homeLabel: 'TBD', awayLabel: 'TBD' },
]

type RoundTreeItem = {
  id: KnockoutStage
  title: string
  matchups: Array<{ id: string; homeLabel: string; awayLabel: string }>
}

export const KNOCKOUT_ROUND_TREE: RoundTreeItem[] = [
  {
    id: 'round_of_16',
    title: 'Round of 16',
    matchups: KNOCKOUT_FIXTURES,
  },
  {
    id: 'quarter_final',
    title: 'Quarter Finals',
    matchups: [
      { id: 'qf-1', homeLabel: 'Winner Match 1', awayLabel: 'Winner Match 2' },
      { id: 'qf-2', homeLabel: 'Winner Match 3', awayLabel: 'Winner Match 4' },
      { id: 'qf-3', homeLabel: 'Winner Match 5', awayLabel: 'Winner Match 6' },
      { id: 'qf-4', homeLabel: 'Winner Match 7', awayLabel: 'Winner Match 8' },
    ],
  },
  {
    id: 'semi_final',
    title: 'Semi Finals',
    matchups: [
      { id: 'sf-1', homeLabel: 'Winner QF1', awayLabel: 'Winner QF2' },
      { id: 'sf-2', homeLabel: 'Winner QF3', awayLabel: 'Winner QF4' },
    ],
  },
  {
    id: 'final',
    title: 'Final',
    matchups: [
      { id: 'final-1', homeLabel: 'Winner SF1', awayLabel: 'Winner SF2' },
    ],
  },
]
